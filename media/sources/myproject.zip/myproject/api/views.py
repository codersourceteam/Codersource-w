from rest_framework.response import Response

from rest_framework.decorators import api_view

@api_view(['GET'])
def get_data(request):
    person = {'name':'Muhammad','age':19}
    return Response(person)